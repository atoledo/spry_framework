#!/usr/bin/env bash

function spry_welcome() {

  echo -e "${BGREEN}            / \ / \ / \ / \   / \ / \ / \ / \ / \ / \ / \ / \ / \  ${COLOR_OFF}"
  echo -e "${BGREEN}           ( S | p | r | y ) ( F | r | a | m | e | w | o | r | k ) ${COLOR_OFF}"
  echo -e "${BGREEN}            \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/  ${COLOR_OFF}\n"

  echo -e "${BYELLOW} Welcome to Spry Framework - Symplifying your DevOps shell scripts development! ${COLOR_OFF}\n"
  echo -e "${BYELLOW} ============================================================================== ${COLOR_OFF}\n"

}

function spry_info() {

  local _LINE_BREAK=""
  [ ${#} -ge 2 ] && [ ${2} -eq 1 ] && _LINE_BREAK="\n"

  printf "${_LINE_BREAK}${BBLUE}[$(date +%H:%M:%S)][ * ] $1 ${COLOR_OFF}\n"

}

function spry_success() {

  local _LINE_BREAK=""
  [ ${#} -ge 2 ] && [ ${2} -eq 1 ] && _LINE_BREAK="\n"

  printf "${_LINE_BREAK}${BGREEN}[$(date +%H:%M:%S)][ ✔ ] $1 ${COLOR_OFF}\n"

}

function spry_danger() {

  local _LINE_BREAK=""
  [ ${#} -ge 2 ] && [ ${2} -eq 1 ] && _LINE_BREAK="\n"

  printf "${_LINE_BREAK}${BRED}[$(date +%H:%M:%S)][ ✘ ] $1 ${COLOR_OFF}\n"

}

function spry_warning() {

  local _LINE_BREAK=""
  [ ${#} -ge 2 ] && [ ${2} -eq 1 ] && _LINE_BREAK="\n"

  printf "${_LINE_BREAK}${BYELLOW}[$(date +%H:%M:%S)][ ! ] $1 ${COLOR_OFF}\n"

}

function spry_question() {

  local _LINE_BREAK=""
  [ ${#} -ge 2 ] && [ ${2} -eq 1 ] && _LINE_BREAK="\n"

  printf "${_LINE_BREAK}${BYELLOW}[$(date +%H:%M:%S)][ ? ] $1 ${COLOR_OFF}\n"

}

function spry_check_status() {

  _LINE_BREAK=""
  [ ${#} -ge 4 ] && [ ${4} -eq 1 ] && _LINE_BREAK="\n"

  _STATUS_CODE=${1}

  [ ${_STATUS_CODE} -eq 0 ] && spry_success "$2" && return 0
  [ ${_STATUS_CODE} -ne 0 ] && spry_danger "$3" && return 0

}

function spry_error() {

  spry_danger "$1"
  exit 1;

}

function spry_end() {

  spry_success "Installation finished!"
  spry_info "Project name [ ${_SPRY_INSTALLER_NAME} ]"
  spry_info "Project alias [ ${_SPRY_INSTALLER_ALIAS} ]"
  spry_info "Instalation path [ ${_SPRY_INSTALLER_PROJECT_DIR} ]"
  spry_info "Run [ source ${_SPRY_INSTALLER_SHELL_HOME} ] command to reload environment"
  spry_info "Run ${_SPRY_INSTALLER_ALIAS} [SPACE] [TAB] to see all tasks."
  spry_question "Please remember to commit the .env file I just created for you!!! [${_SPRY_INSTALLER_PROJECT_DIR}/.env]"

}
