#!/usr/bin/env bash

function _spry_installer_get_config_by_name() {

  local _SPRY_INSTALLER_CONFIGURATION=$(cat ${_SPRY_INSTALLER_CONFIGURATION_FILE} | grep "^${_SPRY_INSTALLER_NAME}#")
  echo "${_SPRY_INSTALLER_CONFIGURATION}"

}

function _spry_installer_get_path_by_name() {

  if [ -z $1 ]; then

    local _SPRY_INSTALLER_NAME=${1}

  fi

  local _SPRY_INSTALLER_CONFIGURATION=$(cat ${_SPRY_INSTALLER_CONFIGURATION_FILE} | grep "^${_SPRY_INSTALLER_NAME}#" | cut -d"#" -f 3)
  echo "${_SPRY_INSTALLER_CONFIGURATION}"

}

function _spry_installer_get_config_by_alias() {

  local _SPRY_INSTALLER_CONFIGURATION=$(cat ${_SPRY_INSTALLER_CONFIGURATION_FILE} | grep "#${_SPRY_INSTALLER_ALIAS}#")
  echo "${_SPRY_INSTALLER_CONFIGURATION}"

}

function _spry_installer_get_config_by_path() {

  local _SPRY_INSTALLER_CONFIGURATION=$(cat ${_SPRY_INSTALLER_CONFIGURATION_FILE} | grep "#${_SPRY_INSTALLER_DIR}/${_SPRY_INSTALLER_NAME}$")
  echo "${_SPRY_INSTALLER_CONFIGURATION}"

}

function _spry_installer_get_name() {

  local _SPRY_INSTALLER_CONFIGURATION=${1}
  local _SPRY_INSTALLER_CONFIG_NAME=$(echo ${_SPRY_INSTALLER_CONFIGURATION} | cut -d"#" -f 1)
  echo "${_SPRY_INSTALLER_CONFIG_NAME}"

}

function _spry_installer_get_alias() {

  local _SPRY_INSTALLER_CONFIGURATION=${1}
  local _SPRY_INSTALLER_CONFIG_ALIAS=$(echo ${_SPRY_INSTALLER_CONFIGURATION} | cut -d"#" -f 2)
  echo "${_SPRY_INSTALLER_CONFIG_ALIAS}"

}

function _spry_installer_get_path() {

  local _SPRY_INSTALLER_CONFIGURATION=${1}
  local _SPRY_INSTALLER_CONFIG_PATH=$(echo ${_SPRY_INSTALLER_CONFIGURATION} | cut -d"#" -f 3)
  echo "${_SPRY_INSTALLER_CONFIG_PATH}"

}
