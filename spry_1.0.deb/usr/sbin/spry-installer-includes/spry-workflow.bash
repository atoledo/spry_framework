#!/usr/bin/env bash

function spry_install() {

  spry_welcome

  case ${1:-} in

     '--help' | '-h')   _spry_installer_list_projects ;;
     '--version' | '-v')   _spry_installer_list_projects ;;
     '--list' | '-l')   _spry_installer_list_projects ;;

    *) spry_question "Do you have a git repository with an existing Spry project? [Y/n]"
      read _SPRY_INSTALLER_OPTION

      [ -z "${_SPRY_INSTALLER_OPTION}" ] && _SPRY_INSTALLER_OPTION="Y"

      case $_SPRY_INSTALLER_OPTION in
        [Yy]) _spry_installer_start_configuration ;;
        [Nn]) _spry_installer_start_new_project ;;
        *) spry_error "Invalid option [ ${_SPRY_INSTALLER_OPTION} ], allowed options: [ Yy/Nn ]." ;;
      esac

    ;;
  esac
  echo

}

function _spry_installer_start_configuration() {

  _spry_installer_set_repo
  spry_success "[${_SPRY_INSTALLER_REPO}] will be used as project repository"

  spry_question "Please enter git branch [master]:"
  read _SPRY_INSTALLER_BRANCH

  spry_question "Please enter where the project will be placed. If empty will be saved here [$PWD]:"
  read _SPRY_INSTALLER_DIR

  [[ -z ${_SPRY_INSTALLER_BRANCH} ]] && _SPRY_INSTALLER_BRANCH='master'
  [[ -z ${_SPRY_INSTALLER_DIR} ]] && _SPRY_INSTALLER_DIR=$(pwd)

  _spry_installer_load_repository
  _spry_installer_prepare_application

  if ( _spry_installer_validate ); then

    spry_success "Validation complete, proceeding with installation"

    _spry_installer_move_project
    _spry_installer_create_project_env
    _spry_installer_register_on_environment
    _spry_installer_prepare_autocomplete

    spry_success "Project configured succefully!"

    _spry_installer_install_dependencies
    spry_end

  else

    spry_error "Project exists. [ ${_SPRY_INSTALLER_NAME} or ${_SPRY_INSTALLER_ALIAS} or ${_SPRY_INSTALLER_PROJECT_DIR} ]"

  fi

}

function _spry_installer_start_new_project() {

  _SPRY_INSTALLER_REPO="git@bitbucket.org:ciandt_it/spry_framework"
  _SPRY_INSTALLER_BRANCH="master"

  _spry_installer_set_name
  spry_success "[${_SPRY_INSTALLER_NAME}] will be used as project name"

  _spry_installer_set_alias
  spry_success "[${_SPRY_INSTALLER_ALIAS}] will be used as project alias"

  spry_question "Please enter where the project will be placed. If empty I'll save here [$PWD]:" 1
  read _SPRY_INSTALLER_DIR

  spry_success "[${_SPRY_INSTALLER_DIR}] will be used as project directory"

  [[ -z ${_SPRY_INSTALLER_DIR} ]] && _SPRY_INSTALLER_DIR=$(pwd)

  _SPRY_INSTALLER_PROJECT_DIR="${_SPRY_INSTALLER_DIR}/${_SPRY_INSTALLER_NAME}"

  if ( _spry_installer_validate ); then

    spry_success "Validation complete, proceeding with installation"

    _spry_installer_load_repository
    [[ -d ${_SPRY_INSTALLER_TMP_DIR} ]] && rm -rf "${_SPRY_INSTALLER_TMP_DIR}/.git"

    spry_warning "Configuring project" 1
    _spry_installer_move_project
    _spry_installer_create_project_env
    _spry_installer_register_on_environment
    _spry_installer_prepare_autocomplete

    spry_success "Project configured succefully!"

    _spry_installer_install_dependencies
    spry_end

  else

    spry_error "Project exists. [ ${_SPRY_INSTALLER_NAME} or ${_SPRY_INSTALLER_ALIAS} or ${_SPRY_INSTALLER_PROJECT_DIR} ]"

  fi

}

function _spry_installer_list_projects() {

    spry_success "Listing installed projects!"

    local _SPRY_PROJECTS_NAME=$(cat ${_SPRY_INSTALLER_CONFIGURATION_FILE} | cut -d "#" -f1 )

    for _SPRY_INSTALLER_NAME in ${_SPRY_PROJECTS_NAME}; do

      local _SPRY_PROJECT_PATH=$(_spry_installer_get_path_by_name ${_SPRY_INSTALLER_NAME})
      spry_warning "Project [ ${_SPRY_INSTALLER_NAME} ] installed in path [ ${_SPRY_PROJECT_PATH} ]."

    done

}
