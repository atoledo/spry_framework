#!/usr/bin/env bash

# paths configuration
_SPRY_INSTALLER_HOME="${HOME}/.spry"
_SPRY_INSTALLER_CONFIGURATION_FILE="${_SPRY_INSTALLER_HOME}/spry_framework.conf"
_SPRY_INSTALLER_PROJECTS="${_SPRY_INSTALLER_HOME}/projects"
_SPRY_INSTALLER_AUTOLOAD="${_SPRY_INSTALLER_HOME}/spry_loader.sh"

[[ ! -d "${_SPRY_INSTALLER_HOME}" ]] && mkdir -p ${_SPRY_INSTALLER_HOME}
[[ ! -d "${_SPRY_INSTALLER_PROJECTS}" ]] && mkdir -p ${_SPRY_INSTALLER_PROJECTS}
[[ ! -f "${_SPRY_INSTALLER_CONFIGURATION_FILE}" ]] && > ${_SPRY_INSTALLER_CONFIGURATION_FILE}

[[ "${SHELL}" == *"/bin/zsh" ]] && _SPRY_INSTALLER_SHELL_HOME="${HOME}/.zshrc"
[[ "${SHELL}" == *"/bin/bash" ]] && _SPRY_INSTALLER_SHELL_HOME="${HOME}/.bashrc"
[[ ! -f "${_SPRY_INSTALLER_SHELL_HOME}" ]] && > ${_SPRY_INSTALLER_SHELL_HOME}

#Reset
COLOR_OFF='\033[0m'       # Text Reset
# Bold
BBLACK='\033[1;30m'       # Black
BRED='\033[1;31m'         # Red
BGREEN='\033[1;32m'       # Green
BYELLOW='\033[1;33m'      # Yellow
BBLUE='\033[1;34m'        # Blue
BPURPLE='\033[1;35m'      # Purple
BCYAN='\033[1;36m'        # Cyan
BWHITE='\033[1;37m'       # White
