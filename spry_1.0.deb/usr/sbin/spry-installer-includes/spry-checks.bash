#!/usr/bin/env bash

function _spry_installer_validate() {

  spry_warning "Validating before installation" 1

  if [ -d "${_SPRY_INSTALLER_PROJECT_DIR}" ]; then

    spry_error "Installation folder already exists [ ${_SPRY_INSTALLER_PROJECT_DIR} ]" 1

  elif ( _spry_installer_check_already_configured_name ); then

    local _SPRY_INSTALLER_CONFIG_LINE=$(_spry_installer_get_config_by_name)
    local _SPRY_INSTALLER_CONFIG_PATH=$(_spry_installer_get_path ${_SPRY_INSTALLER_CONFIG_LINE})
    spry_error "Project with name [${_SPRY_INSTALLER_NAME}] already installed in [${_SPRY_INSTALLER_CONFIG_PATH}]"

  elif ( _spry_installer_check_already_configured_alias ); then

    local _SPRY_INSTALLER_CONFIG_LINE=$(_spry_installer_get_config_by_alias)
    local _SPRY_INSTALLER_CONFIG_PATH=$(_spry_installer_get_path ${_SPRY_INSTALLER_CONFIG_LINE})
    spry_error "Project with alias [${_SPRY_INSTALLER_ALIAS}] already installed in [${_SPRY_INSTALLER_CONFIG_PATH}]"

  elif ( _spry_installer_check_already_configured_path ); then

    local _SPRY_INSTALLER_CONFIG_LINE=$(_spry_installer_get_config_by_path)
    local _SPRY_INSTALLER_CONFIG_NAME=$(_spry_installer_get_name ${_SPRY_INSTALLER_CONFIG_LINE})
    spry_error "Project [${_SPRY_INSTALLER_CONFIG_NAME}] already installed in [${_SPRY_INSTALLER_PROJECT_DIR}]"

  elif ( _spry_installer_check_uniq_alias ); then

    spry_error "This alias [${_SPRY_INSTALLER_ALIAS}] is already used in your system"

  else

    return 0

  fi

  return 1

}

function _spry_installer_check_already_configured_name() {

  local _SPRY_INSTALLER_CONFIGURATION=$(_spry_installer_get_config_by_name)
  if [ -z "${_SPRY_INSTALLER_CONFIGURATION}" ]; then

    return 1;

  fi

  return 0;

}

function _spry_installer_check_already_configured_alias() {

  local _SPRY_INSTALLER_CONFIGURATION=$(_spry_installer_get_config_by_alias)
  if [ -z "${_SPRY_INSTALLER_CONFIGURATION}" ]; then

    return 1;

  fi

  return 0;

}

function _spry_installer_check_already_configured_path() {

  local _SPRY_INSTALLER_CONFIGURATION=$(_spry_installer_get_config_by_path)
  if [ -z "${_SPRY_INSTALLER_CONFIGURATION}" ]; then

    return 1;

  fi

  return 0;

}

function _spry_installer_check_uniq_alias() {

  local _SPRY_INSTALLER_CHECK_ALIAS=$(which ${_SPRY_INSTALLER_ALIAS})
  if [ -z "${_SPRY_INSTALLER_CHECK_ALIAS}" ]; then

    return 1;

  fi

  return 0;

}
