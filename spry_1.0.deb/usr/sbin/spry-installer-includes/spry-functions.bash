#!/usr/bin/env bash

function _spry_installer_set_repo() {

  spry_question "Please enter git URL:" 1
  read _SPRY_INSTALLER_REPO

  if [ -z "${_SPRY_INSTALLER_REPO}" ]; then

    _spry_installer_set_repo

  fi

}

function _spry_installer_set_name() {

  spry_question "Please enter the project name:" 1
  read _SPRY_INSTALLER_NAME

  if [ -z "${_SPRY_INSTALLER_NAME}" ]; then

    _spry_installer_set_name

  fi

}

function _spry_installer_set_alias() {

  spry_question "Please enter the project alias: [ ${_SPRY_INSTALLER_NAME} ]:" 1
  spry_info "The alias will be used to call your tasks. Choose an unique short alias."
  read _SPRY_INSTALLER_ALIAS

  if [ -z "${_SPRY_INSTALLER_NAME}" ]; then

    _SPRY_INSTALLER_ALIAS=${_SPRY_INSTALLER_NAME}

  fi

}

function _spry_installer_load_repository() {

  _SPRY_INSTALLER_TMP_DIR=$(mktemp -d /tmp/repoXXXXX)

  [[ ! -d "${_SPRY_INSTALLER_DIR}" ]] && mkdir -p ${_SPRY_INSTALLER_DIR}

  spry_info "Dowloading git repository into temp folder" 1

  git clone ${_SPRY_INSTALLER_REPO} ${_SPRY_INSTALLER_TMP_DIR} -b ${_SPRY_INSTALLER_BRANCH}
  local _SPRY_INSTALLER_CLONE_STATUS=$?

  spry_check_status ${_SPRY_INSTALLER_CLONE_STATUS} "Clone repository successfully" "Error while clone the repository"
  if [[ ${_SPRY_INSTALLER_CLONE_STATUS} -ge 1 ]]; then

    exit;

  fi

}

function _spry_installer_prepare_application() {

  spry_warning "Preparing application" 1

  if [[ -f "${_SPRY_INSTALLER_TMP_DIR}/.env" ]]; then

    spry_info "Loading configuration from dotenv file. [ ${_SPRY_INSTALLER_TMP_DIR}/.env ]"
    source "${_SPRY_INSTALLER_TMP_DIR}/.env"
    _SPRY_INSTALLER_NAME=${_SPRY_FRAMEWORK_PROJECT_NAME}
    _SPRY_INSTALLER_ALIAS=${_SPRY_FRAMEWORK_PROJECT_ALIAS}

    spry_info "Loading project name from project environment file. [ ${_SPRY_INSTALLER_NAME} ]"
    spry_info "Loading project alias from project environment file. [ ${_SPRY_INSTALLER_ALIAS} ]"

  else

    local _SPRY_INSTALLER_REPO_NAME=$(basename ${_SPRY_INSTALLER_REPO/.git/}) # %%.* Remove extension

    spry_question "Please enter the project name. [ ${_SPRY_INSTALLER_REPO_NAME} ]:"
    read _SPRY_INSTALLER_NAME

    [[ -z ${_SPRY_INSTALLER_NAME} ]] && _SPRY_INSTALLER_NAME=${_SPRY_INSTALLER_REPO_NAME}

    spry_success "[${_SPRY_INSTALLER_NAME}] will be used as project name"

    spry_question "Please enter the project alias. [ ${_SPRY_INSTALLER_NAME} ]:"
    read _SPRY_INSTALLER_ALIAS

    [[ -z ${_SPRY_INSTALLER_ALIAS} ]] && _SPRY_INSTALLER_ALIAS=${_SPRY_INSTALLER_NAME}

    spry_success "[${_SPRY_INSTALLER_ALIAS}] will be used as project alias"

  fi

  _SPRY_INSTALLER_PROJECT_DIR="${_SPRY_INSTALLER_DIR}/${_SPRY_INSTALLER_NAME}"

  if [[ -d ${_SPRY_INSTALLER_PROJECT_DIR} ]]; then

    spry_error "Folder already exists. [ ${_SPRY_INSTALLER_PROJECT_DIR} ]"

  fi

}

function _spry_installer_prepare_autocomplete() {

  [[ "${SHELL}" == *"/bin/zsh" ]] && _spry_installer_prepare_zsh_autocomplete
  [[ "${SHELL}" == *"/bin/bash" ]] && _spry_installer_prepare_bash_autocomplete

}

function _spry_installer_prepare_bash_autocomplete() {

  spry_info "Configuring project bash autocomplete on [${_SPRY_INSTALLER_PROJECTS}/${_SPRY_INSTALLER_NAME}_rc.bash]"

  cat <<EOF | tee "${_SPRY_INSTALLER_PROJECTS}/${_SPRY_INSTALLER_NAME}_rc.bash"  > /dev/null 2>&1
#!/usr/bin/env bash

# Alias of main script
alias ${_SPRY_INSTALLER_ALIAS}=${_SPRY_INSTALLER_PROJECT_DIR}/main.sh && export _SPRY_SCRIPT_ALIAS=${_SPRY_INSTALLER_ALIAS}

if [[ -d "${_SPRY_INSTALLER_PROJECT_DIR}/tasks" ]]; then

  function _spry_${_SPRY_INSTALLER_ALIAS}_framework_autocomplete() {
    local cur prev
    COMPREPLY=()
    tasks=\$(find "${_SPRY_INSTALLER_PROJECT_DIR}/tasks" -type f -iname "*.sh" -not -iname ".*.sh" |egrep -o "\w+.sh$" | sed 's/\.sh//g');
    cur="\${COMP_WORDS[COMP_CWORD]}"
    COMPREPLY=( \$(compgen -W "\${tasks}" -- \${cur}) )

    return 0
  }

  complete -o nospace -F _spry_${_SPRY_INSTALLER_ALIAS}_framework_autocomplete ${_SPRY_INSTALLER_ALIAS}

fi

EOF

  chmod 777 "${_SPRY_INSTALLER_PROJECTS}/${_SPRY_INSTALLER_NAME}_rc.bash"

}

function _spry_installer_prepare_zsh_autocomplete() {

  spry_info "Configuring project zsh autocomplete"

  cat <<EOF | tee "${_SPRY_INSTALLER_PROJECTS}/${_SPRY_INSTALLER_NAME}_rc.bash"  > /dev/null 2>&1
alias ${_SPRY_INSTALLER_ALIAS}=${_SPRY_INSTALLER_PROJECT_DIR}/main.sh  && export _SPRY_SCRIPT_ALIAS=${_SPRY_INSTALLER_ALIAS}

if [[ -d "${_SPRY_INSTALLER_PROJECT_DIR}/tasks" ]]; then

  function _spry_${_SPRY_INSTALLER_ALIAS}_framework_autocomplete() {

    find "${_SPRY_INSTALLER_PROJECT_DIR}/tasks" -type f -iname "*.sh" -not -iname ".*.sh" |egrep -o "\w+.sh$" | sed 's/\.sh//g'

  }

  _spry_${_SPRY_INSTALLER_ALIAS}_framework_complete () {

    compadd \$(_spry_${_SPRY_INSTALLER_ALIAS}_framework_autocomplete)

  }

  compdef _spry_${_SPRY_INSTALLER_ALIAS}_framework_complete ${_SPRY_INSTALLER_PROJECT_DIR}/main.sh

fi
EOF

  chmod 777 "${_SPRY_INSTALLER_PROJECTS}/${_SPRY_INSTALLER_NAME}_rc.bash"

}

function _spry_installer_move_project() {

  spry_info "Moving project from temp folder into desired location [${_SPRY_INSTALLER_PROJECT_DIR}]" 1

  mv ${_SPRY_INSTALLER_TMP_DIR} "${_SPRY_INSTALLER_PROJECT_DIR}"

}

function _spry_installer_create_project_env() {

  if [ ! -f "${_SPRY_INSTALLER_PROJECT_DIR}/.env" ]; then

    spry_info "Creating project contiguration file in [${_SPRY_INSTALLER_PROJECT_DIR}/.env]"
    cat <<EOF | tee "${_SPRY_INSTALLER_PROJECT_DIR}/.env"  > /dev/null 2>&1
_SPRY_FRAMEWORK_PROJECT_NAME="${_SPRY_INSTALLER_NAME}"
_SPRY_FRAMEWORK_PROJECT_ALIAS="${_SPRY_INSTALLER_ALIAS}"

EOF

  fi

}


function _spry_installer_register_on_environment() {

  spry_info "Creating project mapping on [${_SPRY_INSTALLER_CONFIGURATION_FILE}]"

  [[ ! -d "${_SPRY_INSTALLER_DIR}" ]] && mkdir -p ${_SPRY_INSTALLER_DIR}

  echo "${_SPRY_INSTALLER_NAME}#${_SPRY_INSTALLER_ALIAS}#${_SPRY_INSTALLER_PROJECT_DIR}" >> ${_SPRY_INSTALLER_CONFIGURATION_FILE}

  _spry_installer_register_project_autoload

}

function _spry_installer_project_rollback_clean() {

  spry_danger "Rollbacking instalation. [ ${_SPRY_INSTALLER_PROJECT_DIR} ]"
  [[ -d "${_SPRY_INSTALLER_PROJECT_DIR}" ]] && spry_danger "Remove git repository path. [ ${_SPRY_INSTALLER_PROJECT_DIR} ]" && rm -rf ${_SPRY_INSTALLER_PROJECT_DIR}

  exit 10;

}

function _spry_installer_register_project_autoload() {

  spry_info "Creating application auto loader on [${_SPRY_INSTALLER_AUTOLOAD}]"

  if [ ! -f ${_SPRY_INSTALLER_AUTOLOAD} ]; then

cat <<EOF | tee "${_SPRY_INSTALLER_AUTOLOAD}"  > /dev/null 2>&1
#!/usr/bin/env bash

_SPRY_AUTOLOAD_PROJECTS_FILES=\$(find ${_SPRY_INSTALLER_PROJECTS} -name "*_rc.bash")

function projects_autoload() {

  local _FILE=""
  for _FILE in \$@; do

    if [ -n \${_FILE} ] && [ -f \${_FILE} ]; then

      source \${_FILE}

    fi

  done

}

projects_autoload "\${_SPRY_AUTOLOAD_PROJECTS_FILES}"

EOF

  fi

  if(! grep -qwo "### SPRY FRAMEWORK ###" "${_SPRY_INSTALLER_SHELL_HOME}"); then

cat <<EOF | tee -a "${_SPRY_INSTALLER_SHELL_HOME}"  > /dev/null 2>&1

### SPRY FRAMEWORK ###
if [ -x ${_SPRY_INSTALLER_AUTOLOAD} ]; then

  source ${_SPRY_INSTALLER_AUTOLOAD}

fi

EOF

  fi

  chmod 777 ${_SPRY_INSTALLER_AUTOLOAD}

}

function _spry_installer_install_dependencies() {

  spry_warning "Installing project dependencies" 1
  local _SPRY_INSTALLER_PROJECT_DEPENDENCIES="${_SPRY_INSTALLER_PROJECT_DIR}/installer.sh"
  if [[ -f ${_SPRY_INSTALLER_PROJECT_DEPENDENCIES} ]]; then

    source "${HOME}/.spry/projects/${_SPRY_INSTALLER_NAME}_rc.bash"
    source "${_SPRY_INSTALLER_PROJECT_DIR}/.env"
    ${_SPRY_INSTALLER_PROJECT_DEPENDENCIES}

  else

    spry_danger "Installer dependencies not found in: ${_SPRY_INSTALLER_PROJECT_DEPENDENCIES}"

  fi

}
